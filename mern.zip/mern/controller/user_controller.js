// import bcrypt from 'bcrypt'
// import { User } from "../models/user_models.js";
// export const register=async(req,resp) =>{
//     const{name,email,password}=req.body;

//     if (!name || !email || !password){
//         return resp.status(400).json({
//             error:"All fields are required"
//         });
//     }
// }

// const isPresent = await User.findOne({email});
// if (isPresent){
//     return resp.status(400).json({
//         error:"User or email already exist"
//     });

// }
//     const hashpass=await bcrypt.hash(password,10);
//     const user=new User({
//         name,
//         email,
//         password:hashpass
//     });
//     user.save();
//     return resp.status(200).json({
//         message:"User register successfully"
//     });

import bcrypt from 'bcrypt';
import { User } from "../models/user_models.js";

export const register = async (req, resp) => {
    const { name, email, password } = req.body;

    // Validate or check thee input fields
    if (!name || !email || !password) {
        return resp.status(400).json({
            error: "All fields are required"
        });
    }

    // Check if the user already exists
    const isPresent = await User.findOne({ email });
    if (isPresent) {
        return resp.status(400).json({
            error: "User or email already exists"
        });
    }

    // Hash the password
    // const salt = await bcrypt.genSalt(10);
    const hashpass = await bcrypt.hash(password,10);

    // Create a new user
    const user = new User({
        name,
        email,
        password: hashpass
    });

    // Save the user and respond
    await user.save();

    return resp.status(201).json({
        message: "User registered successfully"
    });
};

export const login = async(req,resp)=>{
    const{email,password}=req.body;
    if(!email || !password){
        return resp.status(400).json({
            message:"Field cannot be empty",
        });
    }

    const user= await User.findOne({email});
    if(!user){
        return resp.status(400).json({
            message:"User is not present"
        });
    }

    const isMatch= await bcrypt.compare(password,user.password);
    if (!isMatch){
        return resp.status(400).json({
            message:"Username or password does not match"
        });
    }

    const{_id,name}=user;
    return resp.status(200).json({
        message:"Welcome back",
        id:_id,
        name,
        email
    });
}