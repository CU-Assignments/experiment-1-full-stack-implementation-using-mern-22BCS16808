import mongoose from 'mongoose';
export const connectDB=async()=>{
    try{
        await mongoose.connect("mongodb+srv://advns9744:aditya@cluster0.xirsn.mongodb.net/");
        console.log("Database Connected");
    }catch(error){
        console.error('MongoDB Connection Failed:', error.message);
    }
}
