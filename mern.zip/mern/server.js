import { connectDB } from './common/db.js';
import express from 'express';
import userRoute from './routes/user_routes.js';
const app = express();
app.use(express.json());
app.use("/api",userRoute);
const PORT = 8000;
app.get('/',(req,res)=>{
    res.send('Welcome');
})
app.listen(PORT,() => {
    console.log(`Server running on port http://localhost:${PORT}`);
    connectDB();
});
